This is a sample directory for trial usage.

You can grab files with:

```sh
rpget https://github.com/bisquit/rpget/tree/main/sample
```
